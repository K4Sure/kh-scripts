#!/bin/bash
# CSML Installer with Backup Routine
# v1.0.0-prelaunch

LIBDIR="$HOME/kh-scripts/library/symbols"
BACKUPDIR="$HOME/kh-scripts/backup"
LOGFILE="$HOME/kh-scripts/logs/csml-install.log"

echo "=== Installing CSML v1.0.0-prelaunch ==="
echo "Started at: $(date)" | tee "$LOGFILE"

# Backup existing files
for file in symbols.sh symbols-demo.sh symbols-cheatsheet.txt; do
  if [ -f "$LIBDIR/$file" ]; then
    ts=$(date +%Y%m%d-%H%M%S)
    cp "$LIBDIR/$file" "$BACKUPDIR/${file}.bak-$ts"
    echo "Backed up $file -> $BACKUPDIR/${file}.bak-$ts" | tee -a "$LOGFILE"
  fi
done

if [ -f "$HOME/kh-scripts/csml-full-test.sh" ]; then
  ts=$(date +%Y%m%d-%H%M%S)
  cp "$HOME/kh-scripts/csml-full-test.sh" "$BACKUPDIR/csml-full-test.sh.bak-$ts"
  echo "Backed up csml-full-test.sh" | tee -a "$LOGFILE"
fi

# --- Main library ---
cat <<'LIB' > "$LIBDIR/symbols.sh"
#!/bin/bash
# Characters & Symbols Master Library (CSML)
# v1.0.0-prelaunch

CSML_VERSION="v1.0.0-prelaunch"
CSML_BACKUP="$HOME/kh-scripts/backup"
CSML_LOG="$HOME/kh-scripts/logs/csml.log"

csml_log() {
  echo "[$(date '+%F %T')] $*" >> "$CSML_LOG"
}

csml_version() {
  echo "CSML $CSML_VERSION"
}

csml_symbol() {
  case "$1" in
    arrow_up)    printf '↑' || printf '^' ;;
    arrow_down)  printf '↓' || printf 'v' ;;
    arrow_left)  printf '←' || printf '<' ;;
    arrow_right) printf '→' || printf '>' ;;
    arrow_both)  printf '↔' || printf '<>' ;;
    arrow_vert)  printf '↕' || printf '|' ;;
    star_full)   printf '★' || printf '*' ;;
    star_empty)  printf '☆' || printf 'o' ;;
    star_four)   printf '✦' || printf '+' ;;
    star_spark)  printf '✧' || printf '.' ;;
    block_full)  printf '█' || printf '#' ;;
    block_half)  printf '▓' || printf '=' ;;
    block_light) printf '░' || printf '.' ;;
    block_mid)   printf '▒' || printf '-' ;;
    check)       printf '✔' || printf 'OK' ;;
    cross)       printf '✘' || printf 'X' ;;
    heart)       printf '♥' || printf '<3' ;;
    music)       printf '♪' || printf '~' ;;
    *) printf '?' ;;
  esac
}
LIB
chmod +x "$LIBDIR/symbols.sh"

# --- Demo script ---
cat <<'DEMO' > "$LIBDIR/symbols-demo.sh"
#!/bin/bash
source ~/kh-scripts/library/symbols/symbols.sh

echo "== Characters & Symbols Master Library Demo =="
csml_version
echo

echo "Arrows:"
echo " Up:    $(csml_symbol arrow_up)"
echo " Down:  $(csml_symbol arrow_down)"
echo " Left:  $(csml_symbol arrow_left)"
echo " Right: $(csml_symbol arrow_right)"
echo " Both:  $(csml_symbol arrow_both), $(csml_symbol arrow_vert)"
echo

echo "Stars:"
echo " Full:  $(csml_symbol star_full)"
echo " Empty: $(csml_symbol star_empty)"
echo " Four:  $(csml_symbol star_four)"
echo " Spark: $(csml_symbol star_spark)"
echo

echo "Blocks:"
echo " Full:  $(csml_symbol block_full)"
echo " Half:  $(csml_symbol block_half)"
echo " Mid:   $(csml_symbol block_mid)"
echo " Light: $(csml_symbol block_light)"
echo

echo "Misc:"
echo " Check: $(csml_symbol check)"
echo " Cross: $(csml_symbol cross)"
echo " Heart: $(csml_symbol heart)"
echo " Music: $(csml_symbol music)"
DEMO
chmod +x "$LIBDIR/symbols-demo.sh"

# --- Cheatsheet ---
cat <<'SHEET' > "$LIBDIR/symbols-cheatsheet.txt"
== CSML Cheatsheet v1.0.0-prelaunch ==

Arrows:
 arrow_up    → ↑   (fallback: ^)
 arrow_down  → ↓   (fallback: v)
 arrow_left  → ←   (fallback: <)
 arrow_right → →   (fallback: >)
 arrow_both  → ↔   (fallback: <>)
 arrow_vert  → ↕   (fallback: |)

Stars:
 star_full   → ★   (fallback: *)
 star_empty  → ☆   (fallback: o)
 star_four   → ✦   (fallback: +)
 star_spark  → ✧   (fallback: .)

Blocks:
 block_full  → █   (fallback: #)
 block_half  → ▓   (fallback: =)
 block_mid   → ▒   (fallback: -)
 block_light → ░   (fallback: .)

Misc:
 check       → ✔   (fallback: OK)
 cross       → ✘   (fallback: X)
 heart       → ♥   (fallback: <3)
 music       → ♪   (fallback: ~)
SHEET

# --- Expanded Full Test ---
cat <<'TEST' > "$HOME/kh-scripts/csml-full-test.sh"
#!/bin/bash
# CSML Combined Test Suite (Expanded)
# v1.0.0-prelaunch

LOGFILE="$HOME/kh-scripts/logs/csml-test.log"

echo "=== CSML v1.0.0-prelaunch Combined Test Suite ==="
echo "Started at: $(date)" | tee "$LOGFILE"
echo >> "$LOGFILE"

# Section 1: Version
echo "[1] Version" | tee -a "$LOGFILE"
bash -c "source ~/kh-scripts/library/symbols/symbols.sh && csml_version" | tee -a "$LOGFILE"
echo >> "$LOGFILE"

# Section 2: Arrows
echo "[2] Arrows Test" | tee -a "$LOGFILE"
for s in arrow_up arrow_down arrow_left arrow_right arrow_both arrow_vert; do
  out=$(bash -c "source ~/kh-scripts/library/symbols/symbols.sh && csml_symbol $s")
  printf "%-12s -> %s %s %s\n" "$s" "$out" "$out" "$out" | tee -a "$LOGFILE"
done
echo >> "$LOGFILE"

# Section 3: Stars
echo "[3] Stars Test" | tee -a "$LOGFILE"
for s in star_full star_empty star_four star_spark; do
  out=$(bash -c "source ~/kh-scripts/library/symbols/symbols.sh && csml_symbol $s")
  printf "%-12s -> %s %s %s\n" "$s" "$out" "$out" "$out" | tee -a "$LOGFILE"
done
echo >> "$LOGFILE"

# Section 4: Blocks
echo "[4] Blocks Test" | tee -a "$LOGFILE"
for s in block_full block_half block_mid block_light; do
  out=$(bash -c "source ~/kh-scripts/library/symbols/symbols.sh && csml_symbol $s")
  printf "%-12s -> %s %s %s\n" "$s" "$out" "$out" "$out" | tee -a "$LOGFILE"
done
echo >> "$LOGFILE"

# Section 5: Misc
echo "[5] Misc Test" | tee -a "$LOGFILE"
for s in check cross heart music; do
  out=$(bash -c "source ~/kh-scripts/library/symbols/symbols.sh && csml_symbol $s")
  printf "%-12s -> %s %s %s\n" "$s" "$out" "$out" "$out" | tee -a "$LOGFILE"
done
echo >> "$LOGFILE"

# Section 6: Demo
echo "[6] Demo Script Output" | tee -a "$LOGFILE"
bash ~/kh-scripts/library/symbols/symbols-demo.sh | tee -a "$LOGFILE"
TEST
chmod +x "$HOME/kh-scripts/csml-full-test.sh"

echo "CSML installation + cheatsheet + full test setup complete!"
