#!/bin/bash
# Characters & Symbols Master Library (CSML)
# v1.2.1 (CML-aware)

CSML_VERSION="v1.2.1"

# Detect CML
if [ -f ~/kh-scripts/library/colors/cml.sh ]; then
# source ~/kh-scripts/library/colors/cml.sh
  CML_READY=1
else
  CML_READY=0
fi

# Detect DBML
if [ -f ~/kh-scripts/library/dynamic_box/dynamic_box.sh ]; then
  source ~/kh-scripts/library/dynamic_box/dynamic_box.sh
  DBML_READY=1
else
  DBML_READY=0
fi

# Symbol lookup
csml_symbol() {
  case "$1" in
    arrow_up)    echo "↑" ;;
    arrow_down)  echo "↓" ;;
    arrow_left)  echo "←" ;;
    arrow_right) echo "→" ;;
    arrow_both)  echo "↔" ;;
    arrow_vert)  echo "↕" ;;
    star_full)   echo "★" ;;
    star_empty)  echo "☆" ;;
    star_four)   echo "✦" ;;
    star_spark)  echo "✧" ;;
    block_full)  echo "█" ;;
    block_half)  echo "▓" ;;
    block_mid)   echo "▒" ;;
    block_light) echo "░" ;;
    check)       echo "✔" ;;
    cross)       echo "✘" ;;
    heart)       echo "♥" ;;
    music)       echo "♪" ;;
    circle_full) echo "●" ;;
    circle_empty)echo "○" ;;
    circle_thin) echo "◯" ;;
    tri_up)      echo "▲" ;;
    tri_down)    echo "▼" ;;
    tri_left)    echo "◀" ;;
    tri_right)   echo "▶" ;;
    diamond_full)echo "◆" ;;
    diamond_empty)echo "◇" ;;
    *)           echo "?" ;;
  esac
}

# Version
csml_version() {
  echo "CSML $CSML_VERSION"
}

# Pretty print with CML + DBML
csml_pretty_section() {
  local title="$1"; shift
  local content="$*"

  if [ "$CML_READY" -eq 1 ]; then
    title_colored="$(cml_cyan "$title")"
  else
    title_colored="$title"
  fi

  if [ "$DBML_READY" -eq 1 ]; then
    box_auto rounded --center "$title_colored" >/dev/null
    echo "$content"
  else
    echo "== $title_colored =="
    echo "$content"
  fi
}
