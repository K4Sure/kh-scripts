#!/bin/bash
# CSML Demo Script v1.2.0

source ~/kh-scripts/library/symbols/csml.sh

echo "== CSML Integrated Demo =="
csml_demo
