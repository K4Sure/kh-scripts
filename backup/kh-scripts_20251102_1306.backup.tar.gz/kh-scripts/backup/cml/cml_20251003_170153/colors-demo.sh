#!/data/data/com.termux/files/usr/bin/bash
# CML Demo Showcase — v4.0.0
# A full-bloomed showcase of all supported color modes & themes.

# source ~/kh-scripts/library/colors/cml.sh

echo "CML demo — version: v4.0.0"
echo

############################
# ANSI COLORS
############################
echo "-- ANSI Colors --"
for style in 0 1; do  # 0=normal, 1=bold
  for fg in {30..37} {90..97}; do
    code="${style};${fg}"
    echo -ne "$(cml::ansi $style $fg) ${code} ${CML_RESET}"
  done
  echo
done
echo

# Backgrounds
echo "-- ANSI Backgrounds --"
for bg in {40..47} {100..107}; do
  echo -ne "$(cml::ansi 0 $bg)m ${bg} ${CML_RESET}"
done
echo -e "\n"

############################
# 256-COLOR GRID
############################
echo "-- 256-color Palette --"
for i in {0..255}; do
  printf "$(cml::fg256 $i)%3d${CML_RESET} " $i
  if (( (i + 1) % 16 == 0 )); then echo; fi
done
echo

############################
# TRUECOLOR GRADIENT
############################
echo "-- TrueColor Gradient --"
for r in {0..255..51}; do
  for g in {0..255..51}; do
    for b in {0..255..51}; do
      echo -ne "$(cml::rgb fg $r $g $b)█${CML_RESET}"
    done
    echo -n " "
  done
  echo
done
echo

############################
# THEMES
############################
echo "-- Themes --"
for theme in classic solarized neon darkwave minimal; do
  cml::set_theme $theme
  echo -e "${theme^}: \
${CML_FG_PRIMARY}Primary${CML_RESET} \
${CML_FG_SECONDARY}Secondary${CML_RESET} \
${CML_FG_ACCENT}Accent${CML_RESET}"
done
echo

############################
# CHEATSHEET
############################
echo "Cheatsheet:"
cat <<'EOF'
  cml::ansi 1 31        # bold red
  cml::fg256 196        # bright red (256)
  cml::rgb fg 255 0 0   # truecolor red
  cml::set_theme neon
  echo "${CML_FG_PRIMARY}text${CML_RESET}"
EOF
