#!/bin/bash
# Template using DBML
source ~/kh-scripts/library/dynamic_box/dynamic_box.sh

# Example usage
box_draw double "DBML Template Ready"
