#!/bin/bash
# CSML Color Test (to confirm theme inheritance from CML)

# Try to source CML theme if available
if [ -f ~/kh-scripts/library/colors/cml.sh ]; then
  source ~/kh-scripts/library/colors/cml.sh
fi

echo "=== CSML Color Test ==="

# Show if variables exist
echo "C_HEADER: [$C_HEADER]sample text${C_RESET}"
echo "C_INFO:   [$C_INFO]sample text${C_RESET}"
echo "C_SYMBOL: [$C_SYMBOL]sample text${C_RESET}"
echo "C_RESET:  [$C_RESET]reset text"
