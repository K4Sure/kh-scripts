# Color Master Library (CML)

**Quick setup to run the Color Master Library in Termux.**

---

## Steps to Run

1. **Load the library:**

```bash
source "/data/data/com.termux/files/home/kh-scripts/library/colors/cml_discovery.sh"
