#!/bin/bash
# Characters & Symbols Master Library (CSML)
# v1.0.0-prelaunch

CSML_VERSION="v1.0.0-prelaunch"
CSML_BACKUP="$HOME/kh-scripts/backup"
CSML_LOG="$HOME/kh-scripts/logs/csml.log"

csml_log() {
  echo "[$(date '+%F %T')] $*" >> "$CSML_LOG"
}

csml_version() {
  echo "CSML $CSML_VERSION"
}

csml_symbol() {
  case "$1" in
    arrow_up)    printf '↑' || printf '^' ;;
    arrow_down)  printf '↓' || printf 'v' ;;
    arrow_left)  printf '←' || printf '<' ;;
    arrow_right) printf '→' || printf '>' ;;
    arrow_both)  printf '↔' || printf '<>' ;;
    arrow_vert)  printf '↕' || printf '|' ;;
    star_full)   printf '★' || printf '*' ;;
    star_empty)  printf '☆' || printf 'o' ;;
    star_four)   printf '✦' || printf '+' ;;
    star_spark)  printf '✧' || printf '.' ;;
    block_full)  printf '█' || printf '#' ;;
    block_half)  printf '▓' || printf '=' ;;
    block_light) printf '░' || printf '.' ;;
    block_mid)   printf '▒' || printf '-' ;;
    check)       printf '✔' || printf 'OK' ;;
    cross)       printf '✘' || printf 'X' ;;
    heart)       printf '♥' || printf '<3' ;;
    music)       printf '♪' || printf '~' ;;
    *) printf '?' ;;
  esac
}
