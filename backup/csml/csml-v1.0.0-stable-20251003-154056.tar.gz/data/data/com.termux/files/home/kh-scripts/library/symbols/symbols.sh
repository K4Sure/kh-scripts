#!/bin/bash
# CSML v1.0.0-stable - symbol lookup

case "$1" in
  # Arrows
  arrow_up)    echo "↑" ;;
  arrow_down)  echo "↓" ;;
  arrow_left)  echo "←" ;;
  arrow_right) echo "→" ;;
  arrow_both)  echo "↔" ;;
  arrow_vert)  echo "↕" ;;
  # Stars
  star_full)   echo "★" ;;
  star_empty)  echo "☆" ;;
  star_four)   echo "✦" ;;
  star_spark)  echo "✧" ;;
  # Blocks
  block_full)  echo "█" ;;
  block_half)  echo "▓" ;;
  block_mid)   echo "▒" ;;
  block_light) echo "░" ;;
  # Misc
  check)       echo "✔" ;;
  cross)       echo "✘" ;;
  heart)       echo "♥" ;;
  music)       echo "♪" ;;
  # Fallback
  *) echo "?" ;;
esac
