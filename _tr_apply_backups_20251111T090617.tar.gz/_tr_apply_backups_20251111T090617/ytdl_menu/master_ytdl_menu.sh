#!/data/data/com.termux/files/usr/bin/bash

# DOWNLOAD MENU — Ferrari-red UI + live spinner
# Kelvin edition v3.4.0

set -Eeuo pipefail

VERSION="DOWNLOAD MENU v3.4.0"
PROFILEFILE="$HOME/.currentprofile"
AUDITLOG="/storage/emulated/0/Download/Social Media/Logs/ytdl_menu.log"
WRAPPER="$HOME/bin/bgutil_wrapper.sh"

ARCHIVEROOTEXT="/storage/emulated/0/Download/Social Media/Archives"
DOWNLOADROOTEXT="/storage/emulated/0/Download/Social Media"
COOKIES_ROOT="/storage/emulated/0/Download/Social Media/Cookies"
FALLBACK_ROOT="$HOME/Download/Social Media"
RUNLOGDIR="/storage/emulated/0/Download/Social Media/Logs"

# Size limits in bytes (10MB for logs, 5MB for archives)
LOG_SIZE_LIMIT=$((10 * 1024 * 1024))
ARCHIVE_SIZE_LIMIT=$((5 * 1024 * 1024))

GLOBAL_OPTS=(
    --format bv*+ba/b
    --merge-output-format mp4
    --min-sleep-interval 0.5
    --max-sleep-interval 3.5
    --retries 3
    --fragment-retries 3
    --extractor-retries 3
    --limit-rate 5M
    --yes-playlist
    --max-downloads 100
    --embed-metadata
    --embed-thumbnail
    --continue
)

say(){ printf '%s\n' "$*"; }
banner(){ 
    local text="$1"
    if [[ "$text" == *"v"* ]]; then
        local upper_text=$(echo "$text" | tr '[:lower:]' '[:upper:]' | sed 's/VERSION/version/; s/ V/ v/; s/^V/ v/')
        printf '\n\e[1;31m===[ %s ]===\e[0m\n' "$upper_text"
    else
        printf '\n\e[1;31m===[ %s ]===\e[0m\n' "$(echo "$text" | tr '[:lower:]' '[:upper:]')"
    fi
}
log(){
    mkdir -p "$(dirname "$AUDITLOG")"
    echo "$(date '+%d-%m-%Y %I:%M %p') [YTDLMENU] $*" >> "$AUDITLOG"
}
ensure_writable(){
    local dir="$1"
    mkdir -p "$dir"
    local tmp="$dir/.write_test.$$"
    if : >"$tmp" 2>/dev/null; then
        rm -f "$tmp"
        echo "$dir"
    else
        echo ""
    fi
}
shorten_path() {
    local path="$1"
    path="${path/#\/storage\/emulated\/0/\~}"
    path="${path/#$HOME/\~}"
    echo "$path"
}
downloadcompletebanner(){
    printf "\n\e[1;31m===[ 𝌆 DOWNLOAD COMPLETE — %s 𝌆 ]===\e[0m\n" "$(date '+%d-%m-%Y %I:%M %p')"
}
get_site_color() {
    case "$1" in
        "TikTok") echo "\e[1;36m" ;;
        "Facebook") echo "\e[1;34m" ;;
        "Instagram") echo "\e[1;35m" ;;
        "YouTube") echo "\e[1;31m" ;;
        "YouTube Music") echo "\e[1;38;5;203m" ;;
        "Generic") echo "\e[1;33m" ;;
        *) echo "\e[1;37m" ;;
    esac
}
BEIGE="\e[38;5;223m"
NEON_ORANGE="\e[38;5;208m"
LIGHT_PINK="\e[38;5;218m"
RESET="\e[0m"
rotate_if_needed() {
    local file="$1"
    local size_limit="$2"
    local max_backups=5
    
    if [[ -f "$file" ]]; then
        local file_size=$(stat -c%s "$file" 2>/dev/null || wc -c < "$file" 2>/dev/null)
        
        if [[ $file_size -gt $size_limit ]]; then
            local backup_file="${file}.$(date +%Y%m%d_%H%M%S).bak"
            cp "$file" "$backup_file"
            : > "$file"
            local backup_files=("$file".*.bak)
            if [[ ${#backup_files[@]} -gt $max_backups ]]; then
                ls -t "$file".*.bak 2>/dev/null | tail -n +$(($max_backups + 1)) | xargs rm -f 2>/dev/null || true
            fi
            log "Rotated file: $(basename "$file") (size: $file_size bytes)"
        fi
    fi
}

choose_profile(){
    banner "$VERSION"
    echo
    banner "PROFILE SELECTION"
    echo
    echo -e "\e[1;34m🔵 <1> SONIC SOUND\e[0m"
    echo -e "\e[1;35m🟣 <2> CINEMAX VISUAL\e[0m"
    echo -e "\e[1;32m🟢 <3> ANDROID MATRIX\e[0m"
    echo
    echo -e "\e[1;31m===[ ESC TO ABORT... ]===\e[0m"
    echo
    IFS= read -rsn1 k
    [[ -z "$k" || "$k" == $'\e' ]] && { say '[ABORT]'; exit 0; }
    case "$k" in
        1) PROFILE="SONIC SOUND";    PROFILE_COLOR="\e[1;34m" ;;
        2) PROFILE="CINEMAX VISUAL"; PROFILE_COLOR="\e[1;35m" ;;
        3) PROFILE="ANDROID MATRIX"; PROFILE_COLOR="\e[1;32m" ;;
        *) say "[ERROR] INVALID CHOICE"; exit 1 ;;
    esac
    echo "$PROFILE" > "$PROFILEFILE"
    log "PROFILE SET: $PROFILE"
    echo
    printf "${PROFILE_COLOR}===[ %s | %s ]===\e[0m\n" "$VERSION" "$PROFILE"
    echo
}
get_url(){
    banner "ENTER URL"
    echo
    printf "\e[1;38;5;214mPASTE URL: \e[0m"
    read -r raw
    URL=$(echo "$raw" | tr -d '[:space:]' | tr -d '\r\n')
    URL=$(echo "$URL" | sed 's/[?#].*//')
    [[ -z "$URL" || "$URL" != http* ]] && { say "[ABORT] INVALID URL"; exit 1; }
    printf "\e[1;32m[CLEANED]: %s\e[0m\n" "$URL"
    echo
    log "URL CLEANED: $URL"
}
detect_site(){
    case "$URL" in
        *tiktok.com*)             SITE="tiktok" ;;
        *music.youtube.com*)      SITE="youtubemusic" ;;
        *youtube.com|*youtu.be*)  SITE="youtube" ;;
        *instagram.com*)          SITE="instagram" ;;
        *facebook.com*)           SITE="facebook" ;;
        *)                        SITE="generic" ;;
    esac
    case "$SITE" in
        tiktok)        SITE_NAME="TikTok" ;;
        facebook)      SITE_NAME="Facebook" ;;
        instagram)     SITE_NAME="Instagram" ;;
        youtube)       SITE_NAME="YouTube" ;;
        youtubemusic)  SITE_NAME="YouTube Music" ;;
        generic)       SITE_NAME="Generic" ;;
        *)             SITE_NAME="$SITE" ;;
    esac
    AROOT=$(ensure_writable "$ARCHIVEROOTEXT")
    [[ -z "$AROOT" ]] && AROOT=$(ensure_writable "$FALLBACK_ROOT/Archives")
    ARCHIVEFILE="$AROOT/${SITE}_archive.txt"
    mkdir -p "$(dirname "$ARCHIVEFILE")"
    DROOT=$(ensure_writable "$DOWNLOADROOTEXT")
    [[ -z "$DROOT" ]] && DROOT=$(ensure_writable "$FALLBACK_ROOT")
    OUTPUT_DIR="$DROOT/$SITE_NAME"
    mkdir -p "$OUTPUT_DIR"
    COOKIESFILE="$COOKIES_ROOT/${SITE}_cookies.txt"
    [[ -f "$COOKIESFILE" ]] && COOKIESOPT=(--cookies "$COOKIESFILE") || COOKIESOPT=()
    mkdir -p "$RUNLOGDIR"
    RUNLOG="$RUNLOGDIR/$(date +%d-%m-%Y)_${SITE}.log"
    log "SITE: $SITE | ARCHIVE: $ARCHIVEFILE | OUTPUT: $OUTPUT_DIR | COOKIES: ${COOKIESFILE:-NONE}"
}
is_profile_link(){
    case "$SITE" in
        tiktok)       [[ "$URL" =~ /@[^/]+/?$ ]] ;;
        youtubemusic) [[ "$URL" =~ /(channel/|playlist) ]] ;;
        youtube)      [[ "$URL" =~ /(channel/|c/|user/|playlist) ]] ;;
        instagram)    [[ "$URL" =~ instagram\.com/[^/]+/?$ ]] ;;
        facebook)     [[ "$URL" =~ facebook\.com/[^/]+/?$ ]] ;;
        *)            return 1 ;;
    esac
}

choose_action(){
    banner "ACTION"
    echo "1) DOWNLOAD ALL UNSEEN"
    echo "2) PLAY LATEST UNSEEN"
    IFS= read -rsn1 a
    case "$a" in
        1) ACTION="download" ;;
        2) ACTION="play" ;;
        *) say "[ERROR] INVALID CHOICE"; exit 1 ;;
    esac
}
set_notify_theme(){
    NOTIFEMOJI="🟥"; LEDCOLOR="#FF0000"; PROFILE_CODE="GEN"
    case "$PROFILE" in
        "SONIC SOUND")    NOTIFEMOJI="🔵"; LEDCOLOR="#1E90FF"; PROFILE_CODE="SS" ;;
        "CINEMAX VISUAL") NOTIFEMOJI="🟣"; LEDCOLOR="#FF00FF"; PROFILE_CODE="CV" ;;
        "ANDROID MATRIX") NOTIFEMOJI="🟢"; LEDCOLOR="#00C853"; PROFILE_CODE="AM" ;;
    esac
    NOTIFID="ytdlprogress${PROFILE_CODE}"
    NOTIFTITLEPREFIX="${NOTIFEMOJI} ${PROFILE_CODE}"
}
notify_progress(){
    local pct="$1" eta="$2" spd="$3"
    termux-notification --id "$NOTIFID" \
        --title "$NOTIFTITLEPREFIX | YT-DLP ($(echo "$SITE_NAME" | tr '[:lower:]' '[:upper:]'))" \
        --content "DOWNLOADING: ${pct} | ETA ${eta} | ${spd}" \
        --ongoing \
        --led-color "$LEDCOLOR" --led-on 800 --led-off 1200 >/dev/null 2>&1 || true
}
notify_status(){
    local msg="$1" pr="${2:-default}"
    termux-notification --id "$NOTIFID" \
        --title "$NOTIFTITLEPREFIX | YT-DLP ($(echo "$SITE_NAME" | tr '[:lower:]' '[:upper:]'))" \
        --content "$msg" \
        --priority "$pr" \
        --led-color "$LEDCOLOR" --led-on 1200 --led-off 800 >/dev/null 2>&1 || true
}
clear_notification(){ termux-notification-remove "$NOTIFID" >/dev/null 2>&1 || true; }
preflight(){
    [[ -x "$WRAPPER" ]] || { say "[ERROR] WRAPPER MISSING: $WRAPPER"; exit 1; }
    command -v mpv >/dev/null 2>&1 || MPV_MISS=1
    command -v termux-notification >/dev/null 2>&1 && TERMUXAPI=1 || TERMUXAPI=0
    PROFILE=$(cat "$PROFILEFILE" 2>/dev/null || printf 'UNSET')
    case "$PROFILE" in
        "SONIC SOUND")    PROFILE_COLOR="\e[1;34m" ;;
        "CINEMAX VISUAL") PROFILE_COLOR="\e[1;35m" ;;
        "ANDROID MATRIX") PROFILE_COLOR="\e[1;32m" ;;
        *)                PROFILE_COLOR="\e[1;37m" ;;
    esac
    set_notify_theme
}
spin_with_status(){
    local pid="$1"
    local status_file="$2"
    local frames='⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏'
    local i=0
    local len=${#frames}
    local hid=
    if command -v tput >/dev/null 2>&1; then tput civis; hid=1; fi
    while kill -0 "$pid" 2>/dev/null; do
        i=$(( (i+1) % len ))
        local msg
        msg=$(cat "$status_file" 2>/dev/null)
        printf "\r\e[1;31m[%s]\e[0m %s" "${frames:i:1}" "${msg:-WORKING...}"
        sleep 0.1
    done
    printf "\r%*s\r" 120 " "
    if [[ -n "${hid-}" ]]; then tput cnorm; fi
}

run_action(){
    banner "TASK EXECUTION SUMMARY"
    echo
    printf "${LIGHT_PINK}PROFILE${RESET} : ${PROFILE_COLOR}%s\e[0m\n" "$PROFILE"
    local site_color=$(get_site_color "$SITE_NAME")
    printf "${LIGHT_PINK}SITE${RESET}    : ${site_color}%s\e[0m\n" "$(echo "$SITE_NAME" | tr '[:lower:]' '[:upper:]')"
    printf "${LIGHT_PINK}ACTION${RESET}  : ${NEON_ORANGE}%s${RESET}\n" "$(echo "$ACTION" | tr '[:lower:]' '[:upper:]')"
    printf "${LIGHT_PINK}URL${RESET}     : ${BEIGE}%s${RESET}\n" "$URL"
    printf "${LIGHT_PINK}ARCHIVE${RESET} : ${BEIGE}%s${RESET}\n" "$(shorten_path "$ARCHIVEFILE")"
    printf "${LIGHT_PINK}OUTPUT${RESET}  : ${BEIGE}%s${RESET}\n" "$(shorten_path "$OUTPUT_DIR")"
    if [[ -n "$COOKIESFILE" ]]; then
        printf "${LIGHT_PINK}COOKIES${RESET} : ${BEIGE}%s${RESET}\n" "$(shorten_path "$COOKIESFILE")"
    else
        printf "${LIGHT_PINK}COOKIES${RESET} : NONE\n"
    fi
    printf "${LIGHT_PINK}LOG${RESET}     : ${BEIGE}%s${RESET}\n" "$(shorten_path "$RUNLOG")"
    echo
    log "RUN START | $ACTION | $URL"
    rotate_if_needed "$RUNLOG" "$LOG_SIZE_LIMIT"
    rotate_if_needed "$ARCHIVEFILE" "$ARCHIVE_SIZE_LIMIT"
    {
        set +e
        if [[ "$ACTION" == "download" ]]; then
            MARKER="$(mktemp)"; : >"$MARKER"
            STATUS_FILE="$(mktemp)"
            printf "\e[1;31mPROCESSING...\e[0m" > "$STATUS_FILE"
            (
                "$WRAPPER" -i --ignore-errors \
                "${GLOBAL_OPTS[@]}" "${COOKIESOPT[@]}" \
                --download-archive "$ARCHIVEFILE" \
                --progress-template "PRG %(progress.percentstr)s ETA %(progress.etastr)s SPD %(progress.speedstr)s" \
                -o "$OUTPUT_DIR/%(uploader)s/%(uploader)s%(autonumber)03d.%(ext)s" \
                "$URL"
            ) >>"$RUNLOG" 2>&1 &
            DL_PID=$!
            tail -n0 -F "$RUNLOG" 2>/dev/null | while IFS= read -r line; do
                if [[ "$line" =~ \ Downloading\ item\ ([0-9]+)\ of\ ([0-9]+) ]]; then
                    CUR="${BASH_REMATCH[1]}"; TOT="${BASH_REMATCH[2]}"
                    printf "\e[1;31mDOWNLOADING %s OF %s FILES...\e[0m" "$CUR" "$TOT" > "$STATUS_FILE"
                fi
                if [[ ${TERMUXAPI:-0} -eq 1 && "$line" == PRG* ]]; then
                    pct=$(awk '{print $2}' <<<"$line")
                    eta=$(awk '{print $4}' <<<"$line")
                    spd=$(awk '{print $6}' <<<"$line")
                    notify_progress "$pct" "$eta" "$spd"
                fi
            done &
            TAIL_PID=$!
            spin_with_status "$DL_PID" "$STATUS_FILE"
            wait "$DL_PID"; RC=$?
            kill "$TAIL_PID" 2>/dev/null || true
            rm -f "$STATUS_FILE" 2>/dev/null || true
            VIDEOCOUNT=$(find "$OUTPUT_DIR" -type f -newer "$MARKER" \( -iname "*.mp4" -o -iname "*.mkv" -o -iname "*.webm" \) | wc -l | tr -d ' ')
            PHOTOCOUNT=$(find "$OUTPUT_DIR" -type f -newer "$MARKER" \( -iname "*.jpg" -o -iname "*.jpeg" -o -iname "*.png" -o -iname "*.gif" \) | wc -l | tr -d ' ')
            AUDIOCOUNT=$(find "$OUTPUT_DIR" -type f -newer "$MARKER" \( -iname "*.mp3" -o -iname "*.m4a" -o -iname "*.aac" -o -iname "*.opus" \) | wc -l | tr -d ' ')
            rm -f "$MARKER" 2>/dev/null || true
            [[ ${VIDEOCOUNT:-0} -gt 0 ]] && printf "\e[1;38;5;46mTOTAL VIDEOS DOWNLOADED = %d\e[0m\n" "$VIDEOCOUNT" && log "VIDEOS DOWNLOADED: $VIDEOCOUNT"
            [[ ${PHOTOCOUNT:-0} -gt 0 ]] && printf "\e[1;38;5;46mTOTAL PHOTOS DOWNLOADED = %d\e[0m\n" "$PHOTOCOUNT" && log "PHOTOS DOWNLOADED: $PHOTOCOUNT"
            [[ ${AUDIOCOUNT:-0} -gt 0 ]] && printf "\e[1;38;5;46mTOTAL AUDIOS DOWNLOADED = %d\e[0m\n" "$AUDIOCOUNT" && log "AUDIOS DOWNLOADED: $AUDIOCOUNT"
            [[ ${TERMUXAPI:-0} -eq 1 ]] && notify_status "COMPLETED" high
        else
            if [[ -n "${MPV_MISS-}" ]]; then
                echo "[ERROR] INSTALL MPV: PKG INSTALL -Y MPV"; exit 1
            fi
            "$WRAPPER" -i --ignore-errors \
                "${GLOBAL_OPTS[@]}" "${COOKIESOPT[@]}" \
                --download-archive "$ARCHIVEFILE" \
                --max-downloads 1 -o - "$URL" 2>&1 | tee -a "$RUNLOG" | mpv -
            RC=${PIPESTATUS[0]}
        fi
        set -e
    } 2>&1 | tee -a "$RUNLOG"
    [[ ${TERMUXAPI:-0} -eq 1 ]] && clear_notification
    log "RUN COMPLETE | $ACTION | $URL"
}
rotate_if_needed "$AUDITLOG" "$LOG_SIZE_LIMIT"
choose_profile
get_url
detect_site
preflight
if is_profile_link; then
    ACTION="download"
    run_action
else
    choose_action
    run_action
fi
downloadcompletebanner
echo

