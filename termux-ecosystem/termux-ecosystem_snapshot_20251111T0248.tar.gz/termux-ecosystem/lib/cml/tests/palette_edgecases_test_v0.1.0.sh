#!/usr/bin/env sh
# palette_edgecases_test - ensure quoted values, spaces and stdin overrides apply correctly
set -e
mkdir -p lib/cml/themes
cat > lib/cml/themes/edge_base_v1.0.0.yaml <<Y
name: edge_base
version: 1.0.0
palette:
  x: "#010101"
  y: " #020202 "
Y
cat > lib/cml/themes/edge_ovr_v1.0.0.yaml <<Y
name: edge_ovr
version: 1.0.0
palette:
  y: "#030303"
  z: "#040404"
Y
# test merging with stdin override
out=$(printf 'z: "#050505"\n' | lib/cml/src/cml_palette_v0.3.0.sh lib/cml/themes/edge_base_v1.0.0.yaml lib/cml/themes/edge_ovr_v1.0.0.yaml || true)
norm=$(echo "$out" | sed 's/"//g; s/:[[:space:]]*/:/g')
echo "$norm" | grep -q '^x:' || { echo "FAIL: missing x"; exit 1; }
echo "$norm" | grep -q '^y:#030303' || { echo "FAIL: y not overridden by override"; exit 1; }
echo "$norm" | grep -q '^z:#050505' || { echo "FAIL: stdin override not applied (z)"; exit 1; }
echo "PASS: palette_edgecases_test_v0.1.0"
